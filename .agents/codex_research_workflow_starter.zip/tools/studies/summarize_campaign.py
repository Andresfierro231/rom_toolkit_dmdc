#!/usr/bin/env python3
"""Create a small summary CSV from runtimes_master.csv."""
from __future__ import annotations
import argparse, sys
from collections import Counter
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'reporting'))
from common import read_csv, write_csv, print_written

def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--runtimes', default='analysis/runtimes_master.csv'); ap.add_argument('--out', required=True); a = ap.parse_args()
    rows = read_csv(a.runtimes); statuses = Counter(r.get('status','unknown') for r in rows)
    success = sum(1 for r in rows if str(r.get('success','')).lower() in {'true','1','yes'})
    summary = [{'metric':'total_rows','value':len(rows)}, {'metric':'success_count','value':success}, {'metric':'failure_count','value':len(rows)-success}]
    summary += [{'metric':f'status_{k}','value':v} for k,v in sorted(statuses.items())]
    write_csv(a.out, summary, ['metric','value']); print_written(a.out); return 0
if __name__ == '__main__': raise SystemExit(main())
