#!/usr/bin/env python3
"""Merge per-run JSON rows into one CSV file."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'reporting'))
from common import read_json, write_csv, print_written

def flatten(prefix, obj):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items(): out.update(flatten(f'{prefix}{k}.', v))
        return out
    return {prefix[:-1]: obj}

def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--rows-dir', default='analysis/runtime_rows'); ap.add_argument('--out', default='analysis/runtimes_master.csv'); a = ap.parse_args()
    rows = []
    for p in sorted(Path(a.rows_dir).glob('*.json')):
        try:
            raw = read_json(p); flat = {}
            for k, v in raw.items():
                if isinstance(v, dict): flat.update(flatten(f'{k}.', v)); flat[f'{k}_json'] = json.dumps(v, sort_keys=True)
                else: flat[k] = v
            flat['runtime_row_file'] = str(p); rows.append(flat)
        except Exception as e:
            rows.append({'runtime_row_file': str(p), 'status': 'read_error', 'failure_reason': str(e)})
    if not rows: raise SystemExit(f'No JSON rows found in {a.rows_dir}')
    preferred = ['run_id','campaign_id','timestamp_local','status','success','runtime_sec','input_file','output_file','log_file','failure_reason','runtime_row_file']
    keys = []
    for row in rows:
        for k in row:
            if k not in keys: keys.append(k)
    fields = [k for k in preferred if k in keys] + [k for k in keys if k not in preferred]
    write_csv(a.out, rows, fields); print_written(a.out); print(f'Merged {len(rows)} rows.'); return 0
if __name__ == '__main__': raise SystemExit(main())
