#!/usr/bin/env python3
"""Record a single runtime row as JSON."""
from __future__ import annotations
import argparse, sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'reporting'))
from common import now_local_iso, write_json, print_written

def pairs(items):
    out = {}
    for item in items:
        if '=' not in item: raise SystemExit(f'Expected key=value, got: {item}')
        k, v = item.split('=', 1); out[k] = v
    return out

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-id', required=True); ap.add_argument('--campaign-id', default='')
    ap.add_argument('--status', required=True, choices=['planned','running','success','failed','skipped'])
    ap.add_argument('--runtime-sec', type=float, default=None)
    ap.add_argument('--input-file', default=''); ap.add_argument('--output-file', default=''); ap.add_argument('--log-file', default=''); ap.add_argument('--failure-reason', default='')
    ap.add_argument('--metric', action='append', default=[]); ap.add_argument('--hyperparam', action='append', default=[])
    ap.add_argument('--out-dir', default='analysis/runtime_rows')
    a = ap.parse_args()
    row = {'run_id': a.run_id, 'campaign_id': a.campaign_id, 'timestamp_local': now_local_iso(), 'status': a.status, 'success': a.status == 'success', 'runtime_sec': a.runtime_sec, 'input_file': a.input_file, 'output_file': a.output_file, 'log_file': a.log_file, 'failure_reason': a.failure_reason, 'metrics': pairs(a.metric), 'hyperparams': pairs(a.hyperparam)}
    out = Path(a.out_dir)/f'{a.run_id}.json'; write_json(out, row); print_written(out); return 0
if __name__ == '__main__': raise SystemExit(main())
