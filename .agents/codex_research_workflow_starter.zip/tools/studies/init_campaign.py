#!/usr/bin/env python3
"""Initialize a reproducible campaign folder."""
from __future__ import annotations
import argparse, sys
from datetime import datetime
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'reporting'))
from common import ensure_dir, git_state, now_local_iso, slugify, write_yaml, print_written

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--name', required=True)
    ap.add_argument('--question', required=True)
    ap.add_argument('--reports-root', default='analysis/reports')
    ap.add_argument('--campaigns-root', default='analysis/campaigns')
    a = ap.parse_args()
    campaign_id = f"{datetime.now().strftime('%Y-%m-%d')}_{slugify(a.name)}"
    report_dir = ensure_dir(Path(a.reports_root)/campaign_id)
    for d in ['figures','tables','latex_snippets']: ensure_dir(report_dir/d)
    ensure_dir('analysis/runtime_rows'); ensure_dir(a.campaigns_root)
    cfg_path = Path(a.campaigns_root)/f'{campaign_id}.yaml'
    manifest_path = report_dir/'MANIFEST.yaml'
    cfg = {'campaign_id': campaign_id, 'created_at_local': now_local_iso(), 'name': a.name, 'research_question': a.question, 'status': 'initialized', 'input_files': [], 'validation_files': [], 'run_plan': {'description':'','parameters':{},'planned_runs':[]}, 'analysis': {'metrics': [], 'figures': [], 'tables': []}, 'notes': []}
    manifest = {'campaign_id': campaign_id, 'created_at_local': now_local_iso(), 'research_question': a.question, 'git': git_state('.'), 'inputs': {'input_files': [], 'validation_files': [], 'campaign_config': str(cfg_path)}, 'commands': [], 'scripts_used': [], 'outputs': {'report_dir': str(report_dir), 'runtime_rows_dir': 'analysis/runtime_rows', 'runtimes_master': 'analysis/runtimes_master.csv', 'figures': [], 'tables': [], 'reports': [str(report_dir/'CHECKPOINT.md'), str(report_dir/'CHANGELOG.md'), str(report_dir/'EXECUTIVE_SUMMARY.md'), str(report_dir/'TECHNICAL_REPORT.md')]}, 'metrics': {}, 'known_issues': [], 'next_actions': []}
    write_yaml(cfg_path, cfg); write_yaml(manifest_path, manifest)
    (report_dir/'CHECKPOINT.md').write_text(f'# Checkpoint — {campaign_id}\n\nGenerated: {now_local_iso()}\n\n## Research question\n\n{a.question}\n\n## Current status\n\nInitialized only. No results have been produced yet.\n', encoding='utf-8')
    (report_dir/'CHANGELOG.md').write_text(f'# Changelog — {campaign_id}\n\n- Initialized campaign.\n', encoding='utf-8')
    (report_dir/'EXECUTIVE_SUMMARY.md').write_text(f'# Executive Summary — {campaign_id}\n\nNot yet written.\n', encoding='utf-8')
    (report_dir/'TECHNICAL_REPORT.md').write_text(f'# Technical Report — {campaign_id}\n\nNot yet written.\n', encoding='utf-8')
    for p in [cfg_path, manifest_path, report_dir/'CHECKPOINT.md', report_dir/'CHANGELOG.md', report_dir/'EXECUTIVE_SUMMARY.md', report_dir/'TECHNICAL_REPORT.md']:
        print_written(p)
    print('Campaign ID:', campaign_id)
    return 0
if __name__ == '__main__': raise SystemExit(main())
