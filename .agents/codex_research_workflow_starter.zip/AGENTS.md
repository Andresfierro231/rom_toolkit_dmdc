# AGENTS.md

## Repository role

This repository supports research computing, simulation, analysis, validation, report writing, and reproducible figure/table generation.

Codex must treat this as a research codebase where provenance, reproducibility, and traceability are as important as code changes.

## Non-negotiable rules

- Do not invent results, benchmark timings, file paths, validation data, source claims, or successful runs.
- If a result was not produced by an actual command or an existing file, label it as proposed, expected, or not yet verified.
- Before modifying code, inspect the relevant existing files and summarize the current workflow.
- Prefer patching or extending existing scripts over creating duplicate one-off scripts.
- Preserve current workflows unless the user explicitly asks to replace them.
- Handle missing columns/files gracefully and report what was missing.
- Do not commit large raw simulation outputs. Prefer summaries, CSVs, JSON manifests, plots, and compressed/report-ready artifacts.
- Keep every analysis connected to source files, commands, git state, input decks/configs, output files, and validation data.
- Never delete or overwrite prior results without first archiving them or documenting why replacement is safe.

## Standard output contract for analysis work

Every completed analysis task should produce or update:

1. A machine-readable manifest with campaign name, timestamp, git state, commands, scripts, inputs, outputs, metrics, failures, and missing data.
2. A human-readable checkpoint with goal, files inspected, changes made, runs attempted, results found, plots/tables generated, unresolved issues, and next actions.
3. Report-ready artifacts: clean CSV tables, vector figures, TikZ/PGFPlots wrappers when practical, and LaTeX snippets.

## Preferred analysis locations

- Campaign definitions: `analysis/campaigns/*.yaml`
- Runtime row truth: `analysis/runtime_rows/<run_id>.json`
- Master runtime table: `analysis/runtimes_master.csv`
- Reports: `analysis/reports/<campaign_id>/`
- Journal entries: `analysis/journals/YYYY-MM/YYYY-MM-DD_*.md`
- Reusable study scripts: `tools/studies/`
- Reusable reporting helpers: `tools/reporting/`
- Provenance helpers: `tools/provenance/`

## Preferred workflow

For each analysis task:

1. Inspect repository state.
2. Identify source files and prior artifacts.
3. Create or update a campaign YAML if the task involves runs or analysis.
4. Run or prepare analysis using reusable scripts.
5. Write per-run JSON summaries when runs are performed.
6. Merge summaries into a master CSV when appropriate.
7. Compute validation metrics against available validation data when relevant.
8. Generate figures/tables from saved data, not from hidden notebook state.
9. Write a checkpoint report.
10. Update the journal with enough detail for future report writing.

## Figure requirements

Every report figure should have a source data CSV, generation script or documented command, manifest row, PDF/SVG outputs when practical, TikZ/PGFPlots `.tex` wrapper when practical, readable labels, units, captions, and short scenario names.

Avoid raster-only figures unless the plot cannot reasonably be represented as vector graphics.

## Reporting style

Use clear, dissertation-safe language. Distinguish observed result, inferred interpretation, assumption, limitation, unresolved issue, and recommended next action.
