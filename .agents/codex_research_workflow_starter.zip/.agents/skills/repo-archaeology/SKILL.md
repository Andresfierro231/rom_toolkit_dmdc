---
name: repo-archaeology
description: Use when asked to understand, modify, adapt, or extend this repository. Inspect existing scripts, configs, outputs, reports, and conventions before proposing changes.
---

# Repo archaeology skill

## Goal

Build a grounded understanding of the current repository before editing.

## Required steps

1. Identify current working directory, git branch, commit, and git status.
2. List relevant files without scanning huge output directories.
3. Inspect existing README files, configs, workflow scripts, recent reports, and analysis outputs.
4. Identify current sources of truth for run plans, raw outputs, summaries, validation/reference data, reports, plotting scripts, and executable/environment setup.
5. Summarize active workflow, legacy workflow, files that should not be touched, likely extension points, risks, and ambiguities.
6. Do not modify files during this skill unless explicitly requested.

## Output

A. Repository understanding  
B. Existing workflow map  
C. Relevant files inspected  
D. Risks and ambiguities  
E. Recommended modification plan
