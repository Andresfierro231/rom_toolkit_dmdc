---
name: run-campaign
description: Use for campaign creation, parameter sweeps, model runs, experiments, runtime tracking, validation, and campaign reporting.
---

# Run campaign skill

## Goal

Create or execute a reproducible campaign with traceable inputs, outputs, metrics, and reports.

## Required artifacts

Each campaign should produce or update:

- `analysis/campaigns/<campaign_id>.yaml`
- `analysis/runtime_rows/<run_id>.json` when individual runs are performed
- `analysis/runtimes_master.csv` when runtime rows exist
- `analysis/reports/<campaign_id>/MANIFEST.yaml`
- `analysis/reports/<campaign_id>/CHECKPOINT.md`

## Required behavior

- Never claim a run succeeded unless output files prove it.
- If only a plan was created, say only a plan was created.
- For failed runs, preserve logs and summarize failure signatures.
- Use existing analysis scripts where possible.
- Avoid duplicating functionality already present in the repository.

## Output

A. Campaign purpose  
B. Files inspected  
C. Commands run or prepared  
D. Outputs created  
E. Validation metrics  
F. Known failures  
G. Report-ready conclusions  
H. Next actions
